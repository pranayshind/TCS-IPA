'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
class PAN:
 def __init__(self,ID,M,B,P,C):
  self.ID=ID
  self.M=M
  self.B=B
  self.P=P
  self.C=C
  
class Solution:
 @staticmethod
 
 def costliest_pan(l,M1):
  l1=[]
  for i in l:
   if i.M==M1:
    l1.append(i.P)
  if l1==[]:
   return None
  else:
   for j in l:
    if j.P==max(l1):
     return j.ID
  
 @staticmethod
 def Discounted_price(l,B1):
  for i in l:
   if i.B==B1:
    if 1000>i.C>500:
     i.P=i.P-0.20*i.P
     print(int(i.P))
    elif i.c>100:
     i.P=i.P-0.26*i.P
     print(int(i.P))
    else:
     i.P=i.P
     print(int(i.P))
     
  
    
  
n =int(input())
l=[]
for i in range(n):
 ID=input()
 M=input()
 B=input()
 P=int(input())
 C=int(input())
 l.append(PAN(ID,M,B,P,C))
 
M1=input()
B1=input()
o1=Solution()
o2=o1.costliest_pan(l,M1)
if o2==None:
 print("No material found")
else:
 print(o2)
o3=o1.Discounted_price(l,B1)

