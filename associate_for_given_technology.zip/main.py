'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
class Associate:
 def __init__(self,ID,N,T,E):
  self.ID=ID
  self.N=N
  self.T=T
  self.E=E

class Solution:
 @staticmethod
 def associatesForGivenTechnology(l,T1):
  l1=[]
  for i in l:
   if i.T==T1 and i.E%5==0:
    l1.append(i.ID)
  if l1==[]:
   return None
  else:
   return l1
 
n=int(input())
l=[]
for i in range(n):
 ID=int(input())
 N=input()
 T=input()
 E=int(input())
 l.append(Associate(ID,N,T,E))
T1=input()
o1=Solution()
o2=o1.associatesForGivenTechnology(l,T1)
if o2==None:
 print("No data found")
else:
 for i in o2:
  print(i)
 