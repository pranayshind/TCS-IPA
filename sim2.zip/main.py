'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''

class Sim:
    def __init__(self,ID,N,B,R,C):
        self.ID=ID
        self.N=N
        self.B=B
        self.R=R
        self.C=C

        
class Solution:
    @staticmethod
    def transferCustomerCircle(l,C1,C2):
        l1=[]
        for i in l:
            if i.C==C1:
                i.C=C2
                l1.append(i)
        if l1==[]:
            return None
        else:
            l1.sort(key=lambda x:x.R,reverse=True)
            return l1
                
        
l=[]
n=int(input())
for i in range(n):
    ID=int(input())
    N=input()
    B=float(input())
    R=float(input())
    C=input()
    l.append(Sim(ID,N,B,R,C))
C1=input()
C2=input()
o1=Solution()
o2=o1.transferCustomerCircle(l,C1,C2)
if o2==None:
    print("No data found")
else:
    for i in o2:
        print(i.ID,i.N,i.C,i.R)
