'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
class Medicine:
 def __init__(self,N,B,D,P):
  self.N=N
  self.B=B
  self.D=D
  self.P=P
class Solution:
 @staticmethod
 def getPriceByDisease(l,D1):
  l1=[]
  for i in l:
   if i.D.lower()==D1.lower():
    l1.append(i.P)
  l1.sort()
  return l1
  
n=int(input())
l=[]
for i in range(n):
 N=input()
 B=input()
 D=input()
 P=int(input())
 l.append(Medicine(N,B,D,P))
D1=input()
o1=Solution()
o2=o1.getPriceByDisease(l,D1)
for i in o2:
 print(i)
 