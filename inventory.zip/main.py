'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
class Inventory:
    def __init__(self,ID,MQ,CQ,T):
        self.ID=ID
        self.MQ=MQ
        self.CQ=CQ
        self.T=T
        
class Solution:
    @staticmethod
    def replenish(l,T1):
        for i in l:
            if i.T<=T1:
                if i.T>=75:
                    print(i.ID,"Critical Filling")
                elif 74>=i.T>=50:
                    print(i.ID,"Moderate Filling")
                else:
                    print(i.ID,"Non-Critical Filling")
        
l=[]
n=int(input())
for i in range(n):
    ID=int(input())
    MQ=int(input())
    CQ=int(input())
    T=int(input())
    l.append(Inventory(ID,MQ,CQ,T))
T1=int(input())
    
Solution.replenish(l,T1)