'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
class Bill:
    def __init__(self,BN,N,T,BA,S):
        self.BN=BN
        self.N=N
        self.T=T
        self.BA=BA
        self.S=S

class Solution:
    @staticmethod
    def findBillWithMaxBillAmountBasedOnStatus(l,S1):
        l1=[]
        for i in l:
            if i.S==S1:
                l1.append(i.BA)
        if l1==[]:
            return None
        else:
            l2=[]
            for j in l:
                 if j.BA==max(l1):
                     l2.append(j)
                     return l2
    @staticmethod           
    def getCountWithTypeOfConnection(l,T1):
        c=0
        for i in l:
            if i.T==T1:
                c=c+1
        return c
    
        
l=[]
n=int(input())
for i in range(n):
    BN=int(input())
    N=input()
    T=input()
    BA=float(input())
    S=bool(input())
    l.append(Bill(BN,N,T,BA,S))
S1=bool(input())
T1=input()
o1=Solution()
o2=o1.findBillWithMaxBillAmountBasedOnStatus(l,S1)
if o2==None:
    print("There are no bills with given type of connection")
else:
    for i in o2:
        print(str(i.BN)+"#"+i.N)
o3=o1.getCountWithTypeOfConnection(l,T1)
print(o3)
