'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
class Player:
    def __init__(self,ID,N,R,PT,MT):
        self.ID=ID
        self.N=N
        self.R=R
        self.PT=PT
        self.MT=MT
        

class Solution:
    @staticmethod
    def findPlayerWithLowestRuns(l,PT1):
        l1=[]
        for i in l:
            if i.PT==PT1:
                l1.append(i.R)
        if l1==[]:
            return None
        else:
            return min(l1)
    
    @staticmethod
    def findPlayerByMatchType(l,MT1):
        l2=[]
        for i in l:
            if i.MT==MT1:
                l2.append(i.ID)
        if l2==[]:
            return None
        else:
            dd=sorted(l2, reverse=True)
            return dd

l=[]
n=int(input())
for i in range(n):
    ID=int(input())
    N=input()
    R=int(input())
    PT=input()
    MT=input()
    l.append(Player(ID,N,R,PT,MT))
    
PT1=input()
MT1=input()

o1=Solution()
o2=o1.findPlayerWithLowestRuns(l,PT1)
if o2==None:
    print("No such Player")
else:
    print(o2)
o3=o1.findPlayerByMatchType(l,MT1)
if o3==None:
    print("No Player with given matchType")
else:
    for i in o3:
        print(i)