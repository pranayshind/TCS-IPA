'''

                            Online Python Compiler.
                Code, Compile, Run and Debug python program online.
Write your code in this editor and press "Run" button to execute it.

'''
n=int(input())
l=[]
for i in range(n):
    element=input()
    l.append(element)

s=input()    
for j in l:
    if j==s:
        print(l.index(j))
        break
    
    
    