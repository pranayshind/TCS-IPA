'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''

class Book:
    def __init__(self,P,Pr,A,I,T):
        self.P=P
        self.Pr=Pr
        self.A=A
        self.ID=ID
        self.T=T
class Bookstore:
    def __init__(self,Store_name,l):
        self.Store_name=Store_name
        self.l=l
    
    def findMinimumBookByid(self):
        l1=[]
        for i in self.l:
            l1.append(i.ID)
        if l1==[]:
            return None
        else:
            for j in self.l:
                if j.ID==min(l1):
                    return j
    
    def sortBookByid(self):
        l2=[]
        for i in self.l:
            l2.append(i.ID)
        if l2==[]:
            return None
        else:
            dd=sorted(l2)
            return dd
        
        
n=int(input())
l=[]
for i in range(n):
    P=int(input())
    Pr=int(input())
    A=input()
    ID=int(input())
    T=input()
    l.append(Book(P,Pr,A,ID,T))
o1=Bookstore("ABC",l)
o2=o1.findMinimumBookByid()
if o2==None:
    print("No Data Found")
else:
    
    print(o2.P)
    print(o2.Pr)
    print(o2.A)
    print(o2.ID)
    print(o2.T)
o3=o1.sortBookByid()
if o3==None:
    print("No Data Found")
else:
    for i in o3:
        print(i)
        
'''class Book:
    def __init__(self,P,PR,A,ID,T):
        self.P=P
        self.PR=PR
        self.A=A
        self.ID=ID
        self.T=T
        
class BookStore:
    def __init__(self,BN,l):
        self.BN=BN
        self.l=l
    
    def findminimumbookbyid(self):
        l1=[]
        for i in self.l:
            l1.append(i.ID)
        
        if l1==[]:
            return None
        else:
            for j in self.l:
                if j.ID==min(l1):
                    return j
    
    def sortbookbyid(self):
        l2=[]
        for i in self.l:
            l2.append(i.ID)
        if l2==[]:
            return None
        else:
            d=sorted(l2)
            return d
n=int(input())
l=[]
for i in range(n):
    P=int(input())
    PR=int(input())
    A=input()
    ID=input()
    T=input()
    l.append(Book(P,PR,A,ID,T))
o1=BookStore("BC",l)
o2=o1.findminimumbookbyid()
if o2==None:
    print("No data found")
else:
    print(o2.P)
    print(o2.PR)
    print(o2.A)
    print(o2.ID)
    print(o2.ID)

o3=o1.sortbookbyid()
if o3==None:
    print("No data found")
else:
    for i in o3:
        print(i)
'''
