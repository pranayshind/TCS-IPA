'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
class Player:
 def __init__(self,ID,N,R,M,S):
  self.ID=ID
  self.N=N
  self.R=R
  self.M=M
  self.S=S
class Solution:
 @staticmethod
 def findAverageOfRuns(l,M1):
  l1=[]
  for i in l:
   if i.M>=M1:
    l1.append(i)
  for j in l1:
   Avg=j.S/j.M
   if 100>Avg>80:
    print("Grade A")
   elif 79>Avg>50:
    print("Grade B")
   else:
    print("Grade C")
    
 


n=int(input())
l=[]
for i in range(n):
 ID=int(input())
 N=input()
 R=int(input())
 M=int(input())
 S=int(input())
 l.append(Player(ID,N,R,M,S))
M1=int(input())
o1=Solution()
o1.findAverageOfRuns(l,M1)
