'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
class Sim:
 def __init__(self,ID,C,B,R,Ci):
  self.ID=ID
  self.C=C
  self.B=B
  self.R=R
  self.Ci=Ci
class Solution:
 @staticmethod
 def matchAndSort(l,Ci1,R1):
  l1=[]
  for i in l:
   if i.Ci==Ci1 and i.R<R1:
    l1.append(i)
  if l1==[]:
   return None
  else:
   dd=sorted(l1, key=lambda X:X.B , reverse=True)
   return dd

n=int(input())
l=[]
for i in range(n):
 ID=int(input())
 C=input()
 B=int(input())
 R=float(input())
 Ci=input()
 l.append(Sim(ID,C,B,R,Ci))
Ci1=input()
R1=float(input())
o1=Solution()
o2=o1.matchAndSort(l,Ci1,R1)
if o2==None:
 print("No data found")
else:
 for i in o2:
  print(i.ID)
 
  