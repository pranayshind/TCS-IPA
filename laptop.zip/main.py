'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
class Laptop:
    def __init__(self,ID,B,OS,P,R):
        self.ID=ID
        self.B=B 
        self.OS=OS
        self.P=P
        self.R=R

class Solution:
    
    @staticmethod
    def countOfLaptopsByBrand(l,S):
        c=0
        for i in l:
            if i.B.lower()==S.lower():
                if i.R>3:
                    c=c+1
                    
        if c==0:
            return None
        else:
            return c
            
            
    @staticmethod
    def searchLaptopByOsType(l,S1):
        d={}
        for i in l:
            if i.OS.lower()==S1.lower():
                d[i.ID]=i.R
                
        dd=sorted(d.items(), key=lambda x:x[1])
                
        if d=={}:
            return None
        else:
            return dd
            
l=[]
for i in range(4):
    ID=int(input())
    B=input()
    OS=input()
    P=float(input())
    R=int(input())
    l.append(Laptop(ID,B,OS,P,R))
    
S=input()
S1=input()

o1=Solution()
o2=o1.countOfLaptopsByBrand(l,S)
if o2==None:
    print("The given brand is not available")
else:
    print(o2)
    
o3=o1.searchLaptopByOsType(l,S1)
if o3==None:
    print("The given os is not available")
else:
    for k,v in o3:
        print(k)
        print(v)
       
    
    