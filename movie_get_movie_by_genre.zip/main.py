'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
class Movie:
 def __init__(self,MN,C,G,B):
  self.MN=MN
  self.C=C
  self.G=G
  self.B=B
 
class Solution:
 @staticmethod
 def getMovieByGenre(l,G1):
  for i in l:
   if i.G.lower()==G1.lower():
    if i.B>80000000:
     print("High Budget Movie")
    else:
     print("low Budget Movie")
    
  
n=int(input())
l=[]
for i in range(n):
 MN=input()
 C=input()
 G=input()
 B=int(input())
 l.append(Movie(MN,C,G,B))
G1=input()
o1=Solution()
o1.getMovieByGenre(l,G1)