'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
class Phone:
 def __init__(self,ID,OS,B,P):
  self.ID=ID
  self.OS=OS
  self.B=B
  self.P=P
class Solution:
 @staticmethod
 def findPriceForGivenBrand(l,B1):
  l1=[]
  for i in l:
   if i.B.lower()==B1.lower():
    l1.append(i.P)
    
  if l1==[]:
   return None
  else:
   return sum(l1)
   
 @staticmethod  
 def getPhoneIdBasedOnOs(l,OS1):
  l2=[]
  for i in l:
   if i.OS.lower()==OS1.lower() and i.P>=50000:
    l2.append(i.ID)
    
  if l2==[]:
   return None
  else:
   return l2
    
  
n=int(input())
l=[]
for i in range(n):
 ID=int(input())
 OS=input()
 B=input()
 P=int(input())
 l.append(Phone(ID,OS,B,P))
B1=input()
OS1=input()
o1=Solution()
o2=o1.findPriceForGivenBrand(l,B1)
if o2==None:
 print("The given Brand is not available")
else:
 print(o2)
o3=o1.getPhoneIdBasedOnOs(l,OS1)
if o3==None:
 print("The given OS is not available")
else:
 for i in o3:
  print(i)