'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
class Doctor:
 def __init__(self,ID,N,S,F):
  self.ID=ID
  self.N=N 
  self.S=S 
  self.F=F
  
class Hospital:
 def __init__(self,d):
  self.d=d 
  
 def searchByDoctorName(self,name):
  l=[]
  for k,v in self.d.items():
   if v.N.lower()==name.lower():
    l.append(v)
 
  if l==[]:
   return None
  else:
   return l
  
 def calculateConsultationFeeBySpecialization(self,sp):
  c=0
  for k,v in self.d.items():
   if v.S.lower()==sp.lower():
    c=c+v.F

  if c==0:
   return None
  else:
   return c
 
    
  
n=int(input())
d={}
for i in range(n):
 d["ID"]=int(input())
 d["N"]=input()
 d["S"]=input()
 d["F"]=int(input())
 
name=input()
sp=input()

o1=Hospital(d)
o2=o1.searchByDoctorName(name)

if o2==None:
 print("Doctors not found")
else:
 for i in o2:
  print(i)
  
o3=o1.calculateConsultationFeeBySpecialization(sp)
print(o3)
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 