'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
class Icecream:
    def __init__(self,ID,P,N,Q,C):
        self.ID=ID
        self.P=P
        self.N=N
        self.Q=Q
        self.C=C

class IcecreamStore:
    def __init__(self,IN,l):
        self.IN=IN
        self.l=l
        
    def findMinimumIcecreamByPrice(self):
        l1=[]
        for i in self.l:
            l1.append(i.P)
            
        if l1==[]:
            return None
        else:
            for j in self.l:
                if j.P==min(l1):
                   return j
        
                    
    def sortIcecreamByid(self):
        l2=[]
        for i in self.l:
            l2.append(i.ID)
        
        if l2==[]:
            return None
        else:
            dd=sorted(l2)
            return dd
        
          
            


n=int(input())
l=[]
for i in range(n):
    ID=int(input())
    P=int(input())
    N=input()
    Q=int(input())
    C=input()
    l.append(Icecream(ID,P,N,Q,C))
    
o1=IcecreamStore("ABC",l)
o2=o1.findMinimumIcecreamByPrice()
if o2==None:
    print("no data found")
else:
    print(o2.ID)
    print(o2.P)
    print(o2.N)
    print(o2.Q)
    print(o2.C)
o3=o1.sortIcecreamByid()
if o3==None:
    print("no data found")
else:
    for i in o3:
        print(i)