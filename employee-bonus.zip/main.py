'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
#9)
class Employee:
 def __init__(self,N,D,S,d,OTS=False):
  self.N=N
  self.D=D
  self.S=S
  self.d=d
  self.OTS=OTS
  
class Organization:
 def __init__(self,l):
  self.l=l
  
 def eligible(self,th):
  for i in self.l:
   if sum(i.d.values())>=th:
    i.OTS=True
   else:
    i.OTS=False
  
   print(i.N,i.OTS)
    
 def bonus(self,rate):
  l1=[]
  for i in self.l:
   if i.OTS==True:
    l1.append(sum(i.d.values())*rate)
  return sum(l1)
 
n=int(input())
l=[]

for i in range(n):
 N=input()
 D=input()
 S=int(input())
 n1=int(input())
 d={}
 for j in range(n1):
  month=input()
  hour=int(input())
  d[month]=hour
 l.append(Employee(N,D,S,d))
  
th=int(input())
rate=int(input())

o1=Organization(l)
o1.eligible(th)
o3=o1.bonus(rate)
print(o3)


