'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
class Vegetable:
 def __init__(self,N,P,Q):
  self.N=N
  self.P=P
  self.Q=Q
  
class Store:
 def __init__(self,l,SN):
  self.l=l
  self.SN=SN
  
 def categorizeVegetablesAlphabetically(self):
  d={}
  for i in self.l:
   
   d[i.N[0]]=i.N
  dd=sorted(d.items())
  l1=set(dd)
   
  if d=={}:
   return None
  else:
   return l1
    
    
n=int(input())
l=[]
for i in range(n):
 N=input()
 P=float(input())
 Q=int(input())
 l.append(Vegetable(N,P,Q))
  
SN=input()
Min=float(input())
Max=float(input())
  
o1=Store(SN,l)
o2=o1.categorizeVegetablesAlphabetically()
if o2==None:
 print("No vege")
else:
 for i in o2:
  print(i)
  
  