'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
class Sim:
    def __init__(self,ID,N,B,R,C):
        self.ID=ID
        self.N=N
        self.B=B
        self.R=R
        self.C=C

        
class Solution:
    @staticmethod
    def transferCustomerCircle(l,C1,C2):
        l1=[]
        for i in l:
            if i.C.lower()==C1.lower():
                i.C=C2
                l1.append(i)
        if l1==[]:
            print("No found")
        else:
            l1.sort(key=lambda x:x.R, reverse=True)
            for i in l1:
                print(i.ID,i.N,i.C,i.R)
            
                
        
l=[]
n=int(input())
for i in range(n):
    ID=int(input())
    N=input()
    B=float(input())
    R=float(input())
    C=input()
    l.append(Sim(ID,N,B,R,C))
C1=input()
C2=input()

Solution.transferCustomerCircle(l,C1,C2)
